// Implements a dictionary's functionality

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// Number of buckets in hash table
const unsigned int N = 26;

// Dictionary size tracker
int dictionarySize = 0;

// Hash table
node *table[N];

// Returns true if word is in dictionary else false
bool check(const char *word) //DONE
{

    char wordToCheck = *word;
    char *wordTCPtr = &wordToCheck;
    unsigned int hashIndex = hash(wordTCPtr);

    node *cursor = table[hashIndex];

    while (cursor != NULL) //used to be cursor->next
    {
        if (strcasecmp((cursor->word),word) == 0)
        {
            return true;
        }
        else
        {
            cursor = cursor->next;
        }
    }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word) //DONE
{
    //DETERMINE WHERE TO STORE NEW NODE (HASH INDEX) go to lower, ascii 97 - 122 convert to 0-25
    char firstLetter = word[0];
    int hashIndex = tolower(firstLetter) - 97;

    return hashIndex;
}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary) //DONE
{
    char wordBuffer[LENGTH + 1];

    //open dictionary file
    FILE *dictionaryFile = fopen(dictionary, "r");


    if (dictionaryFile == NULL) //file not read
    {
        return false;
    }
    else
    {
        while (fscanf(dictionaryFile, "%s", wordBuffer) != EOF)
        {
            //CREATE NEW NODE
            node *n = malloc(sizeof(node));
            if (n == NULL) //checks that n receives address
            {
                return false;
            }
            strcpy(n->word, wordBuffer); //copy scanned word into node

            //GET HASH INDEX
            unsigned int hashIndex = hash(wordBuffer);

            //ADD NEW NODE TO HASH TABLE
            if (table[hashIndex] == NULL) //if no nodes at that array index yet
            {
                table[hashIndex] = n;
                n->next = NULL;
                dictionarySize++;
            }
            else
            {
                n->next = table[hashIndex];
                table[hashIndex] = n;
                dictionarySize++;
            }

        }
        fclose(dictionaryFile);
        return true;
    }
    return false;
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void) //DONE
{
    return dictionarySize;
}

// Unloads dictionary from memory, returning true if successful else false
bool unload(void) //DONE
{
    node *tmpForFree;
    node *cursor;
    bool complete = false;

    for (int i = 0; i < N; i++)
    {
        tmpForFree = table[i];

        while (tmpForFree != NULL) //FREE UP LINKED LISTS
        {
            cursor = tmpForFree;
            cursor = cursor->next;
            free(tmpForFree);
            tmpForFree = cursor;

        }

        //CHECK ALL TABLE HEADERS
        if (i == 25)
        {
            complete = true;
        }

    }

    return complete;
}
